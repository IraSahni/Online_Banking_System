package com.kpmg.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.entities.Account;
import com.kpmg.entities.ApplicationUser;
import com.kpmg.entities.LoginResponseDTO;
import com.kpmg.entities.RegistrationDTO;
import com.kpmg.services.AuthenticationService;

@RestController
@RequestMapping
//@RequestMapping("/auth")
//@CrossOrigin("*")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthenticationController {

	@Autowired
	public AuthenticationService authenticationService ;
	
	@PostMapping("/api/register")
	public ApplicationUser registerUser(@RequestBody RegistrationDTO body) {
		
		return authenticationService.registerUser(body.getFirstName(),body.getMiddleName(),body.getLastName(),body.getFatherName(),body.getMobileNumber(),body.getEmailID(),body.getAadharNumber(),body.getDateOfBirth(),body.getUsername(),body.getPassword());
	}
	
	@PostMapping("/api/login")
	public LoginResponseDTO loginUser(@RequestBody RegistrationDTO body) {
		
		return authenticationService.loginUser(body.getUsername(), body.getPassword());
	}
	
	@PostMapping("/api/accounts")
	  public ResponseEntity<Account> createAccount(@RequestBody Account account) {
	    Account newAccount = authenticationService.createAccount(account);
	    return ResponseEntity.ok(newAccount);
	  }
	  
	  @GetMapping(value="/api/accounts/{accountId}")
	  public ResponseEntity<Account> getAccount(@PathVariable("accountId") int accountId) {
	    Account account = authenticationService.getAccount(accountId);
	    return ResponseEntity.ok(account);
	  }
	  
}
