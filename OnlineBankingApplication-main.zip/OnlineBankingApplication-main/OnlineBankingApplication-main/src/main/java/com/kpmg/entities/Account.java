package com.kpmg.entities;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "account")
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accountId;

	@OneToMany
	@JoinColumn(name = "transactionIdFk")
	private List<Transaction> transactions;
	
	private double balance;

	public List<Integer> beneficiaries;

	public Account() {
		System.out.print("Account Constructor called");
		this.transactions = new ArrayList<Transaction>();
		this.beneficiaries = new ArrayList<Integer>();
		this.balance = 500000;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<Integer> getBeneficiaries() {
		return beneficiaries;
	}

	public void setBeneficiaries(List<Integer> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}

}
