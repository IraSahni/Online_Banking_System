package com.kpmg.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kpmg.repositories.AccountRepository;

@Service
public class BankService {
	
	   @Autowired
		private AccountRepository accountRepository;
		
	    
	    
}
